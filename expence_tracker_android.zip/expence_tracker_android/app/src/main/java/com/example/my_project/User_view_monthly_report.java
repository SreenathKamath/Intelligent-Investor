package com.example.my_project;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Calendar;

public class User_view_monthly_report extends AppCompatActivity implements JsonResponse {

    ListView lv1;
    Button b1,b2;
    EditText e1;
    SharedPreferences sh;
    String searchitem;
    DatePickerDialog datePickerDialog;
    String [] val,budget_amount,category_name,expense_amount,expense_date,income,balance_amount,category_id,budget_id;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_view_monthly_report);
        sh= PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        lv1=(ListView)findViewById(R.id.lvhot);
        e1=(EditText)findViewById(R.id.searchtxt);
        b1=(Button) findViewById(R.id.searchbtn);
//        lv1.setOnItemClickListener(this);
        e1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // calender class's instance and get current date , month and year from calender
                final Calendar c = Calendar.getInstance();
                int mYear = c.get(Calendar.YEAR); // current year
                int mMonth = c.get(Calendar.MONTH); // current month
                int mDay = c.get(Calendar.DAY_OF_MONTH); // current day
                datePickerDialog = new DatePickerDialog(User_view_monthly_report.this,
                        new DatePickerDialog.OnDateSetListener() {

                            @Override
                            public void onDateSet(DatePicker view, int year,
                                                  int monthOfYear, int dayOfMonth) {
                                if (String.valueOf(monthOfYear).length() == 1){
                                    e1.setText(year+"-"+"0"+monthOfYear);

                                }else{
                                    e1.setText(year+"-"+monthOfYear);

                                }



                            }
                        }, mYear, mMonth, 1);
                datePickerDialog.show();

            }
        });
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                searchitem=e1.getText().toString();

                JsonReq JR=new JsonReq();
                JR.json_response=(JsonResponse)User_view_monthly_report.this;
                String q="/searchreport?searchitem="+searchitem+"&log_id="+sh.getString("log_id","");
//                String q="/searchplace?searchitem="+searchitem;
                q = q.replace(" ", "%20");
                JR.execute(q);
            }
        });

        JsonReq JR=new JsonReq();
        JR.json_response=(JsonResponse) User_view_monthly_report.this;
        String q = "/view_report?log_id=" + sh.getString("log_id", "");
        q=q.replace(" ","%20");
        JR.execute(q);

    }

    @Override
    public void response(JSONObject jo) {
        // TODO Auto-generated method stub
        try {

            String method = jo.getString("method");
            Log.d("pearl", method);


            if (method.equalsIgnoreCase("view_report")) {
                String status = jo.getString("status");
                Log.d("pearl", status);
                if (status.equalsIgnoreCase("success")) {

                    JSONArray ja1 = (JSONArray) jo.getJSONArray("data");

                    category_id = new String[ja1.length()];
                    budget_id = new String[ja1.length()];
                    budget_amount = new String[ja1.length()];
                    category_name = new String[ja1.length()];
                    expense_amount = new String[ja1.length()];
                    expense_date = new String[ja1.length()];
                    income = new String[ja1.length()];
//                    balance_amount = new String[ja1.length()];
                    val = new String[ja1.length()];


                    for (int i = 0; i < ja1.length(); i++) {


                        category_id[i] = ja1.getJSONObject(i).getString("category_id");
                        budget_id[i]=ja1.getJSONObject(i).getString("budget_id");
                        budget_amount[i] = ja1.getJSONObject(i).getString("budget_amount");
                        category_name[i] = ja1.getJSONObject(i).getString("category_name");
                        expense_amount[i] = ja1.getJSONObject(i).getString("expense_amount");
                        expense_date[i] = ja1.getJSONObject(i).getString("expense_date");
                        income[i] = ja1.getJSONObject(i).getString("income");
//                        balance_amount[i] = ja1.getJSONObject(i).getString("balance_amount");
//                        Toast.makeText(getApplicationContext(), val[i], Toast.LENGTH_SHORT).show();
                        val[i] = " Category Name : " + category_name[i] + " \nBudget Amount:" + budget_amount[i]+ "\nExpense Amount:  " + expense_amount[i] + "\nIncome:  " + income[i];


                    }

//                    Toast.makeText(getApplicationContext(), "hello", Toast.LENGTH_SHORT).show();

                    ArrayAdapter<String> ar = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_list_item_1, val);
                    lv1.setAdapter(ar);


                }
                else {
                    Toast.makeText(getApplicationContext(), "No report found this month ", Toast.LENGTH_SHORT).show();
                }
            }

//            if (method.equalsIgnoreCase("Customer_add_to_favorite")) {
//                String status = jo.getString("status");
//                Toast.makeText(getApplicationContext(), status, Toast.LENGTH_LONG).show();
//                if (status.equalsIgnoreCase("success")) {
//                    Toast.makeText(getApplicationContext(), "Favorite Place Added Successfully!", Toast.LENGTH_LONG).show();
//
//                    startActivity(new Intent(getApplicationContext(), Customer_add_to_favorite.class));
//                } else {
////					Toast.makeText(getApplicationContext(),"Interested Place Added Failed", Toast.LENGTH_LONG).show();
//                    Toast.makeText(getApplicationContext(), "Already Added....",
//                            Toast.LENGTH_LONG).show();
//                }
//            }
        } catch (Exception e) {
            // TODO: handle exception

            Toast.makeText(getApplicationContext(), e.toString(), Toast.LENGTH_LONG).show();

        }
    }
    public void onBackPressed()
    {
        // TODO Auto-generated method stub
        super.onBackPressed();
        Intent b=new Intent(getApplicationContext(),User_home.class);
        startActivity(b);

    }
}