package com.example.my_project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

public class User_add_budget_amount extends AppCompatActivity implements JsonResponse {
    EditText e1;
    Button b1;
    String budget_amount;
    String[] budget_amounts,reply,date,value;
    SharedPreferences sh;
    ListView l1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_add_budget_amount);
        sh= PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        e1=(EditText)findViewById(R.id.etcom);
        b1=(Button)findViewById(R.id.button);
        l1=(ListView)findViewById(R.id.lvview);
        JsonReq JR = new JsonReq();
        JR.json_response = (JsonResponse) User_add_budget_amount.this;
        String q = "/view_buget?log_id=" + sh.getString("log_id", "");
        q = q.replace(" ", "%20");
        JR.execute(q);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                budget_amount=e1.getText().toString();
                if(budget_amount.equalsIgnoreCase(""))
                {
                    e1.setError("Enter your amount");
                    e1.setFocusable(true);
                }
                else
                {
                    JsonReq JR=new JsonReq();
                    JR.json_response=(JsonResponse) User_add_budget_amount.this;
                    String q = "/User_add_budget_amount?&log_id=" + sh.getString("log_id", "")+"&budget_amount="+budget_amount;
                    q=q.replace(" ","%20");
                    JR.execute(q);
                }
            }
        });
    }

    @Override
    public void response(JSONObject jo) {
        try {

            String method = jo.getString("method");
            Log.d("pearl", method);


            if (method.equalsIgnoreCase("view_buget")) {

                String status = jo.getString("status");
                if (status.equalsIgnoreCase("success")) {
                    JSONArray ja = (JSONArray) jo.getJSONArray("data");

//                    cid = new String[ja.length()];'


                    budget_amounts = new String[ja.length()];
//                    reply = new String[ja.length()];
                    date = new String[ja.length()];
                    value = new String[ja.length()];


                    for (int i = 0; i < ja.length(); i++) {
//                        cid[i] = ja.getJSONObject(i).getString("complaint_id");
                        budget_amounts[i] = ja.getJSONObject(i).getString("budget_amount");
                        date[i] = ja.getJSONObject(i).getString("budget_date");
                        value[i] = "\nMy Budget : " + budget_amounts[i]  + "\nDate :" + date[i];
                    }


                    l1.setAdapter(new ArrayAdapter<>(getApplicationContext(), android.R.layout.simple_list_item_1, value));
                    {

                    }
                }
            }

            if (method.equalsIgnoreCase("User_add_budget_amount")) {
                try {
                    String status = jo.getString("status");
                    Log.d("pearl", status);


                    if (status.equalsIgnoreCase("success")) {
                        Toast.makeText(getApplicationContext(), " expense added", Toast.LENGTH_LONG).show();
                        startActivity(new Intent(getApplicationContext(), User_add_budget_amount.class));

                    }
                    else {

                        Toast.makeText(getApplicationContext(), " failed.TRY AGAIN!!", Toast.LENGTH_LONG).show();
                    }

                } catch (Exception e) {
                    // TODO: handle exception
                    e.printStackTrace();
                    Toast.makeText(getApplicationContext(), e.toString(), Toast.LENGTH_LONG).show();
                }
            }
        } catch (Exception e) {
            // TODO: handle exception
            e.printStackTrace();
            Toast.makeText(getApplicationContext(), e.toString(), Toast.LENGTH_LONG).show();
        }
    }

    @Override

    public void onBackPressed()
    {

        // TODO Auto-generated method stub
        super.onBackPressed();
        Intent b=new Intent(getApplicationContext(),User_home.class);
        startActivity(b);

    }


}