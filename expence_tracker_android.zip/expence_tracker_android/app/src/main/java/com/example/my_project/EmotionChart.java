package com.example.my_project;

import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import org.eazegraph.lib.charts.PieChart;
import org.eazegraph.lib.models.PieModel;
import org.json.JSONObject;


public class EmotionChart extends AppCompatActivity implements JsonResponse {

    PieChart chart;
    String sad,joy,shame,none;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE); //will hide the title
//        getSupportActionBar().hide(); // hide the title bar
//        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
//                WindowManager.LayoutParams.FLAG_FULLSCREEN); //enable full screen
        setContentView(R.layout.activity_emotion_chart);

        JsonReq JR = new JsonReq();
        JR.json_response = (JsonResponse) EmotionChart.this;
        String q = "/mycommentgraph";
        q = q.replace(" ", "%20");
        JR.execute(q);

        chart = findViewById(R.id.chart);



    }




    @Override
    public void response(JSONObject jo) {
        try {

            String method = jo.getString("method");
            Log.d("pearl", method);

            if (method.equalsIgnoreCase("mycommentgraph")) {
                String status = jo.getString("status");
                if (status.equalsIgnoreCase("success")) {
//        Toast.makeText(getApplicationContext(), i1, Toast.LENGTH_SHORT).show();

                    String joy = jo.getString("joyPercentage");
                    String sad = jo.getString("sadPercentage");
                    String shame = jo.getString("shamePercentage");
                    String noval = jo.getString("novaluePercentage");

                      int i1 = Integer.parseInt(joy);
                      int i2 = Integer.parseInt(sad);
                      int i3 = Integer.parseInt(shame);
                      int i4 = Integer.parseInt(noval);

//                        i1=Integer.parseInt(jo.getString("joyPercentage"));
//                        i2=Integer.parseInt(jo.getString("sadPercentage"));
//                        i3=Integer.parseInt(jo.getString("shamePercentage"));
//                        i4=Integer.parseInt(jo.getString("novaluePercentage"));


                        chart.addPieSlice(new PieModel("Integer 1",i1, Color.parseColor("#FFFACD")));
                        chart.addPieSlice(new PieModel("Integer 2",i2, Color.parseColor("#519c3f")));
                        chart.addPieSlice(new PieModel("Integer 3",i3, Color.parseColor("#DAA520")));
                        chart.addPieSlice(new PieModel("Integer 4",i4, Color.parseColor("#4682B4")));

                        chart.startAnimation();







                } else  if (status.equalsIgnoreCase("failed")) {
                    Toast.makeText(getApplicationContext(), "No Comments for this post!", Toast.LENGTH_SHORT).show();
                }
            }

        }
        catch (Exception e) {
            // TODO: handle exception
            e.printStackTrace();
            Toast.makeText(getApplicationContext(), e.toString(), Toast.LENGTH_SHORT).show();
        }
    }
}