package com.example.my_project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

public class User_home extends AppCompatActivity {
    ImageButton b1,b2,b3,b4,b5,b6,b7,b8;
    TextView t2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_home);
        b1=(ImageButton) findViewById(R.id.product);
        b2=(ImageButton) findViewById(R.id.logout);
        b3=(ImageButton) findViewById(R.id.btcom);
        b4=(ImageButton) findViewById(R.id.budget);
        b5=(ImageButton) findViewById(R.id.file);
        b6=(ImageButton) findViewById(R.id.btreport);
        b7=(ImageButton) findViewById(R.id.btchart);
        b7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(),EmotionChart.class));

            }
        });


        TextView t1 = findViewById(R.id.mainhead);
        t1.setText("Welcome, "+Login.zname+".");

         b6.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View v) {
                 startActivity(new Intent(getApplicationContext(),User_view_monthly_report.class));

             }
         });


        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(),User_add_incomes.class));

            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                startActivity(new Intent(getApplicationContext(),IPSetting.class));
            }
        });
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(),Customer_send_complaint.class));

            }
        });

b4.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        startActivity(new Intent(getApplicationContext(),User_add_budget_amount.class));

    }
});
        b5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(),User_view_category.class));

            }
        });
    }
}