package com.example.my_project;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

public class User_add_category extends AppCompatActivity implements JsonResponse, AdapterView.OnItemClickListener {
    EditText e1;
    Button b1;
    String category;
    String[] categorys,reply,date,value,category_id;
    public static  String category_ids;
    SharedPreferences sh;
    ListView l1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_add_category);
        sh= PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        e1=(EditText)findViewById(R.id.etcom);
        b1=(Button)findViewById(R.id.button);
        l1=(ListView)findViewById(R.id.lvview);
        l1.setOnItemClickListener(this);

        JsonReq JR = new JsonReq();
        JR.json_response = (JsonResponse) User_add_category.this;
        String q = "/view_category?log_id=" + sh.getString("log_id", "");
        q = q.replace(" ", "%20");
        JR.execute(q);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                category=e1.getText().toString();
                if(category.equalsIgnoreCase(""))
                {
                    e1.setError("Enter your category");
                    e1.setFocusable(true);
                }
                else
                {
                    JsonReq JR=new JsonReq();
                    JR.json_response=(JsonResponse) User_add_category.this;
                    String q = "/User_add_category?&log_id=" + sh.getString("log_id", "")+"&category="+category;
                    q=q.replace(" ","%20");
                    JR.execute(q);
                }
            }
        });

    }

    @Override
    public void response(JSONObject jo) {
        try {

            String method = jo.getString("method");
            Log.d("pearl", method);


            if (method.equalsIgnoreCase("view_category")) {

                String status = jo.getString("status");
                if (status.equalsIgnoreCase("success")) {
                    JSONArray ja = (JSONArray) jo.getJSONArray("data");

//                    cid = new String[ja.length()];

                    categorys = new String[ja.length()];
                    category_id = new String[ja.length()];
                    value = new String[ja.length()];


                    for (int i = 0; i < ja.length(); i++) {
                        category_id[i] = ja.getJSONObject(i).getString("category_id");
                        categorys[i] = ja.getJSONObject(i).getString("category_name");
                        value[i] = "\ncategorys : " + categorys[i];
                    }


                    l1.setAdapter(new ArrayAdapter<>(getApplicationContext(), android.R.layout.simple_list_item_1, value));
                    {

                    }
                }
            }

            if (method.equalsIgnoreCase("User_add_category")) {
                try {
                    String status = jo.getString("status");
                    Log.d("pearl", status);


                    if (status.equalsIgnoreCase("success")) {
                        Toast.makeText(getApplicationContext(), " category added ", Toast.LENGTH_LONG).show();
                        startActivity(new Intent(getApplicationContext(), User_add_category.class));

                    }
                    else {

                        Toast.makeText(getApplicationContext(), " failed.TRY AGAIN!!", Toast.LENGTH_LONG).show();
                    }



                } catch (Exception e) {
                    // TODO: handle exception
                    e.printStackTrace();
                    Toast.makeText(getApplicationContext(), e.toString(), Toast.LENGTH_LONG).show();
                }

            }

            if (method.equalsIgnoreCase("catdelete")) {
                String status = jo.getString("status");
                Toast.makeText(getApplicationContext(), status, Toast.LENGTH_LONG).show();
                if (status.equalsIgnoreCase("success")) {
                    Toast.makeText(getApplicationContext(), "Remove Successfully", Toast.LENGTH_LONG).show();
                    startActivity(new Intent(getApplicationContext(), User_add_category.class));
                }
//			else if(status.equalsIgnoreCase("duplicate"))
//			{
//				Toast.makeText(getApplicationContext(), "Duplicate", Toast.LENGTH_LONG).show();
//			}
                else {
                    Toast.makeText(getApplicationContext(), "..........", Toast.LENGTH_LONG).show();

                }


            }


        } catch (Exception e) {
            // TODO: handle exception
            e.printStackTrace();
            Toast.makeText(getApplicationContext(), e.toString(), Toast.LENGTH_LONG).show();
        }
    }

    @Override

    public void onBackPressed()
    {

        // TODO Auto-generated method stub
        super.onBackPressed();
        Intent b=new Intent(getApplicationContext(),User_home.class);
        startActivity(b);

    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        category_ids = category_id[position];
        final CharSequence[] items = {"Remove", "Cancel"};
        AlertDialog.Builder builder = new AlertDialog.Builder(User_add_category.this);
        // builder.setTitle("Add Photo!");
        builder.setItems(items, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int item) {

                if (items[item].equals("Remove")) {
                    JsonReq JR = new JsonReq();
                    JR.json_response = (JsonResponse) User_add_category.this;
                    String q = "/catdelete?category_ids=" + User_add_category.category_ids;
                    q = q.replace(" ", "%20");
                    JR.execute(q);
                }

            }

        });
        builder.show();
    }
}