package com.example.my_project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

public class User_add_incomes extends AppCompatActivity implements JsonResponse {
    EditText e1;
    Button b1,b2,b3;
    String income;
    String[] incomes,reply,date,value;
    SharedPreferences sh;
    ListView l1;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_add_incomes);
        sh= PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        e1=(EditText)findViewById(R.id.etcom);
        b1=(Button)findViewById(R.id.button);
        b2=(Button)findViewById(R.id.bttotal);
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), User_balance.class));

            }
        });
        b3=(Button)findViewById(R.id.btcat);
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), User_add_category.class));

            }
        });
        l1=(ListView)findViewById(R.id.lvview);

        JsonReq JR = new JsonReq();
        JR.json_response = (JsonResponse) User_add_incomes.this;
        String q = "/view_income?log_id=" + sh.getString("log_id", "");
        q = q.replace(" ", "%20");
        JR.execute(q);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                income=e1.getText().toString();
                if(income.equalsIgnoreCase(""))
                {
                    e1.setError("Enter your income");
                    e1.setFocusable(true);
                }
                else
                {
                    JsonReq JR=new JsonReq();
                    JR.json_response=(JsonResponse) User_add_incomes.this;
                    String q = "/User_add_incomes?&log_id=" + sh.getString("log_id", "")+"&income="+income;
                    q=q.replace(" ","%20");
                    JR.execute(q);
                }

            }
        });
    }

    @Override
    public void response(JSONObject jo) {
        try {

            String method = jo.getString("method");
            Log.d("pearl", method);


            if (method.equalsIgnoreCase("view_income")) {

                String status = jo.getString("status");
                if (status.equalsIgnoreCase("success")) {
                    JSONArray ja = (JSONArray) jo.getJSONArray("data");

//                    cid = new String[ja.length()];

                    incomes = new String[ja.length()];
                    reply = new String[ja.length()];
                    date = new String[ja.length()];
                    value = new String[ja.length()];


                    for (int i = 0; i < ja.length(); i++) {
//                        cid[i] = ja.getJSONObject(i).getString("complaint_id");
                        incomes[i] = ja.getJSONObject(i).getString("income");
                        date[i] = ja.getJSONObject(i).getString("income_date");
                        value[i] = "\nAmount : " + incomes[i]  + "\nDate :" + date[i];
                    }


                    l1.setAdapter(new ArrayAdapter<>(getApplicationContext(), android.R.layout.simple_list_item_1, value));
                    {

                    }
                }
            }

            if (method.equalsIgnoreCase("User_add_incomes")) {
                try {
                    String status = jo.getString("status");
                    Log.d("pearl", status);


                    if (status.equalsIgnoreCase("success")) {
                        Toast.makeText(getApplicationContext(), " Amount Added", Toast.LENGTH_LONG).show();
                        startActivity(new Intent(getApplicationContext(), User_balance.class));

                    }
                    else {

                        Toast.makeText(getApplicationContext(), " failed.TRY AGAIN!!", Toast.LENGTH_LONG).show();
                    }

                } catch (Exception e) {
                    // TODO: handle exception
                    e.printStackTrace();
                    Toast.makeText(getApplicationContext(), e.toString(), Toast.LENGTH_LONG).show();
                }
            }
        } catch (Exception e) {
            // TODO: handle exception
            e.printStackTrace();
            Toast.makeText(getApplicationContext(), e.toString(), Toast.LENGTH_LONG).show();
        }
    }

    @Override

    public void onBackPressed()
    {

        // TODO Auto-generated method stub
        super.onBackPressed();
        Intent b=new Intent(getApplicationContext(),User_home.class);
        startActivity(b);

    }

}